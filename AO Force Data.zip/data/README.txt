Datasets are csv files with two columns: Time (seconds), Force (newtons).

Each data records the insertion of a cochlear implant electrode in a 3D printed cochlea model. 

Datasets are labeled: S[Surgeon ID]_T[Trial ID]